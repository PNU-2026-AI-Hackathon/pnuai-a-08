package hacekrton.hackerton;

import org.springframework.boot.SpringApplication;

public class TestHackertonApplication {

	public static void main(String[] args) {
		SpringApplication.from(HackertonApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
